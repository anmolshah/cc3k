#include "dwarf.h"

Dwarf::Dwarf(Grid *g):Enemy(g,100, 30, 20, 'W', "dwarf"){}

