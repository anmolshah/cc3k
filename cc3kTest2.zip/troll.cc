#include "troll.h"
#include <string>

Troll::Troll(Grid *g): Player(g, 120, 15, 25, "troll"){}
