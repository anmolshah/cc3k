#include <string>
#include "shade.h"
using namespace std;

Shade::Shade(Grid *g): Player(g, 125, 25, 25, "shade"){
}

