#!/bin/bash

g++14 *.cc -o game
