#include "goblin.h"
#include <string>

Goblin::Goblin(Grid *g):Player{g, 110, 20, 15, "goblin"}{}
