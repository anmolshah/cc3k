#include <string>
#include "drow.h"
using namespace std;

Drow::Drow(Grid *g): Player{g, 150, 15, 25, "drow"}{}
