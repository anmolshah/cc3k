#include "passageway.h"
#include "subject.h"

PassageWay::PassageWay(int y, int x, char symb): Cell{y, x, symb}, x{x}, y{y}{}
