#include "subject.h"
#include "door.h"

Door::Door(int y, int x, char symb): Cell{y, x, symb}, x{x}, y{y}{}

